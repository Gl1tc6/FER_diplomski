import win32evtlog
import logging
import time
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)
handler = logging.FileHandler("logs/windowsEvents.log")
handler.setFormatter(logging.Formatter("%(message)s"))
logger.addHandler(handler)

serverName = 'localhost'
sourceName = 'Security'
handle = win32evtlog.OpenEventLog(serverName, sourceName)

flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ

while True:
    events = win32evtlog.ReadEventLog(handle, flags, 0)

    for event in events:
        data = {"SourceName": event.SourceName, 
                "EventID": event.EventID, 
                "TimeGenerated": event.TimeGenerated.Format(), 
                "EventType": event.EventType, 
                "EventCategory": event.EventCategory, 
                "StringInserts": event.StringInserts}
        logger.info(json.dumps(data))
    
    time.sleep(1)
