double gettime(void);
