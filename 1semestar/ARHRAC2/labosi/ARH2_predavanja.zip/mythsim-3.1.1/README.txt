MythSim: The Mythical Simulator for Real Students
-------------------------------------------------
Notes for Compiling

1. If you make changes to the flex files you must regenerate new java files.
2. There is a script for making a jar file in the classes directory.
3. There are images that are included in the classes directory, so don't wipe them out.
